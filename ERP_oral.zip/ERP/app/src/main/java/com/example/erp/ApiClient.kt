package com.example.erp // Adaptez votre package

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {

    // Dans ApiClient.kt
    // private const val BASE_URL = "http://VOTRE_IP_RASPBERRY_PI:5000/" // Ancienne valeur
    private const val BASE_URL = "http://192.168.1.34:5000/" // REMPLACEZ 192.168.1.34 par l'IP réelle de votre RPi

    // Intercepteur pour les logs (très utile pour le débogage)
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) { // N'affiche les logs détaillés qu'en mode Debug
            HttpLoggingInterceptor.Level.BODY
        } else {
            HttpLoggingInterceptor.Level.NONE
        }
    }

    // Client OkHttp personnalisé (pour ajouter l'intercepteur de logs, timeouts, etc.)
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS) // Timeout de connexion
        .readTimeout(30, TimeUnit.SECONDS)    // Timeout de lecture
        .writeTimeout(30, TimeUnit.SECONDS)   // Timeout d'écriture
        .build()

    // Instance de Retrofit (lazy pour être créée seulement quand nécessaire)
    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient) // Utiliser notre client OkHttp personnalisé
            .addConverterFactory(GsonConverterFactory.create()) // Spécifier Gson comme convertisseur
            .build()
    }

    // Exposer le service API (lazy également)
    val capteurApiService: CapteurApiService by lazy {
        retrofit.create(CapteurApiService::class.java)
    }
}