package com.example.erp // Adaptez votre package

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.error
import androidx.compose.ui.semantics.text
import com.example.erp.databinding.ActivityLoginBinding // Assurez-vous que le nom correspond

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide() // Cacher l'ActionBar pour un look plus épuré

        binding.buttonLogin.setOnClickListener {
            handleLogin()
        }
    }

    private fun handleLogin() {
        val username = binding.editTextUsername.text.toString().trim()
        val password = binding.editTextPassword.text.toString().trim()

        // --- Logique de validation basique ---
        if (username.isEmpty()) {
            binding.textInputLayoutUsername.error = "Le nom d'utilisateur ne peut pas être vide"
            return
        } else {
            binding.textInputLayoutUsername.error = null // Enlever l'erreur
        }

        if (password.isEmpty()) {
            binding.textInputLayoutPassword.error = "Le mot de passe ne peut pas être vide"
            return
        } else {
            binding.textInputLayoutPassword.error = null // Enlever l'erreur
        }

        // --- Logique de connexion factice ---
        // Remplacez ceci par votre vraie logique d'authentification (API, base de données, etc.)
        // Pour cet exemple, nous allons utiliser des identifiants fixes.
        // NE FAITES JAMAIS CELA EN PRODUCTION !
        val dummyUsername = "admin"
        val dummyPassword = "password123"

        // Simuler un chargement (optionnel, pour montrer la ProgressBar)
        // binding.loginProgressBar.visibility = View.VISIBLE
        // binding.buttonLogin.isEnabled = false

        // Handler().postDelayed({ // Pour simuler un appel réseau
        // binding.loginProgressBar.visibility = View.GONE
        // binding.buttonLogin.isEnabled = true

        if (username == dummyUsername && password == dummyPassword) {
            Toast.makeText(this, "Connexion réussie !", Toast.LENGTH_SHORT).show()

            // Naviguer vers l'activité principale (par exemple, MainActivity ou GraphActivity)
            // Choisissez celle qui doit être la première après la connexion.
            // Si GraphActivity est votre écran principal après connexion :
            val intent = Intent(this, MainActivity::class.java)
            // Optionnel: Effacer la pile d'activités pour que l'utilisateur ne retourne pas à la connexion avec "retour"
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish() // Terminer LoginActivity
        } else {
            Toast.makeText(this, "Nom d'utilisateur ou mot de passe incorrect.", Toast.LENGTH_LONG).show()
            binding.textInputLayoutPassword.error = " " // Petite astuce pour afficher l'erreur sur le champ mdp sans texte précis
        }
        // }, 1500) // Délai de 1.5 secondes
    }
}