package com.example.erp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.example.erp.databinding.Page1activity2Binding

class page1Activity2 : AppCompatActivity() {

    private lateinit var binding: Page1activity2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Page1activity2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            val intent = Intent(this, GraphActivity::class.java)
            startActivity(intent)
        }
        setupSpinner()
        setupSeekBar()
    }

    private fun setupSpinner() {
        val ventilationOptions = arrayOf("Profil1", "profil2", "Profil3", "Automatique")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, ventilationOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinner.adapter = adapter

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedOption = parent.getItemAtPosition(position).toString()
                // TODO: Implémenter la logique pour l'option de ventilation sélectionnée
                // Exemple: Log.d("SpinnerSelection", "Option: $selectedOption")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Non utilisé pour l'instant
            }
        }
    }

    private fun setupSeekBar() {
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // TODO: Implémenter la logique pour le changement de progression du SeekBar
                // Exemple: binding.textViewSomeValue.text = "Vitesse: $progress"
                // Log.d("SeekBarProgress", "Progrès: $progress")
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Non utilisé pour l'instant
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Non utilisé pour l'instant
            }
        })
    }
}