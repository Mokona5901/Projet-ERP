package com.example.erp

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels // Assurez-vous que cet import est présent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.text
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.erp.databinding.ActivityGraph24hBinding // Importez ceci
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class Graph24hActivity : AppCompatActivity() {

    private val TAG = "Graph24hActivity"

    // Initialisation du View Binding
    private lateinit var binding: ActivityGraph24hBinding

    // Initialisation du ViewModel
    private val viewModel: Graph24hViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityGraph24hBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupLineChart()
        observeViewModel()

        viewModel.recupererDonneesCapteursDernieres24h(null)
    }

    private fun setupLineChart() {
        binding.lineChart24h.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            setBackgroundColor(Color.WHITE)
            animateX(1000)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(true)
            }

            axisLeft.apply {
                setDrawGridLines(true)
            }
            axisRight.isEnabled = false
            legend.isEnabled = true
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.donneesCapteurs24hStateFlow.collect { lectures ->
                        Log.d(TAG, "Nouvelles données reçues: ${lectures.size} lectures")
                        if (lectures.isNotEmpty()) {
                            binding.textViewError24h.visibility = View.GONE
                            mettreAJourGraphiqueAvecDonnees(lectures)
                        } else {
                            if (!viewModel.isLoadingStateFlow.value && viewModel.errorMessageStateFlow.value == null) {
                                binding.textViewError24h.text = "Aucune donnée disponible."
                                binding.textViewError24h.visibility = View.VISIBLE
                            }
                            binding.lineChart24h.clear()
                            binding.lineChart24h.invalidate()
                        }
                    }
                }

                launch {
                    viewModel.isLoadingStateFlow.collect { isLoading ->
                        Log.d(TAG, "État de chargement: $isLoading")
                        binding.progressBar24h.visibility = if (isLoading) View.VISIBLE else View.GONE
                        if (isLoading) {
                            binding.textViewError24h.visibility = View.GONE
                        }
                    }
                }

                launch {
                    viewModel.errorMessageStateFlow.collect { errorMessage ->
                        if (errorMessage != null) {
                            Log.e(TAG, "Erreur reçue: $errorMessage")
                            binding.textViewError24h.text = errorMessage
                            binding.textViewError24h.visibility = View.VISIBLE
                            binding.lineChart24h.clear()
                            binding.lineChart24h.invalidate()
                        }
                    }
                }
            }
        }
    }

    private fun mettreAJourGraphiqueAvecDonnees(lectures: List<LectureCapteur>) {
        val entries = ArrayList<Entry>()
        val apiDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.UK).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val displayXAxisFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        lectures.forEach { lecture ->
            try {
                val date = apiDateFormat.parse(lecture.timestamp)
                if (date != null) {
                    entries.add(Entry(date.time.toFloat(), lecture.valeur))
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erreur parsing timestamp '${lecture.timestamp}': ${e.message}")
            }
        }

        if (entries.isEmpty()) {
            Log.w(TAG, "Aucune entrée valide après parsing.")
            binding.lineChart24h.clear()
            binding.lineChart24h.invalidate()
            return
        }

        val dataSet = LineDataSet(entries, "Capteur (24h)").apply {
            color = Color.CYAN
            valueTextColor = Color.BLACK
            lineWidth = 1.8f
            setDrawCircles(true)
            setDrawValues(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            circleRadius = 3f
            setCircleColor(Color.CYAN)
        }

        val lineData = LineData(dataSet)
        binding.lineChart24h.data = lineData

        binding.lineChart24h.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return try {
                    displayXAxisFormat.format(Date(value.toLong()))
                } catch (e: Exception) { "" }
            }
        }
        binding.lineChart24h.xAxis.labelCount = 6
        binding.lineChart24h.xAxis.isGranularityEnabled = true

        binding.lineChart24h.invalidate()
        Log.d(TAG, "Graphique mis à jour avec ${entries.size} entrées.")
    }
}