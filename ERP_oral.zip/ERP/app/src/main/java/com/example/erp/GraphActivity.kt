package com.example.erp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
// import android.util.Log // Décommentez si vous ajoutez des logs
// import android.view.View // Peut être nécessaire si vous ajoutez ProgressBar/TextView pour erreurs. NON UTILISÉ ICI.
import android.widget.Toast // NON UTILISÉ pour le nouveau bouton, mais conservé pour les autres.
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.text
import androidx.compose.ui.tooling.data.position
import androidx.core.text.color
// Les imports Compose ne sont pas utilisés ici et peuvent être supprimés si non nécessaires ailleurs.
// import androidx.compose.ui.semantics.text
// import androidx.compose.ui.tooling.data.position
// import androidx.core.text.color // Non utilisé directement ici.

import com.example.erp.databinding.ActivityGraphBinding
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import java.util.Locale

class GraphActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGraphBinding
    private var selectedZoneId: Int = 1 // Non utilisé dans le code fourni, mais conservé
    private var currentDataType: String = "temperature"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGraphBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Graphique Principal"

        setupMainChartAppearance()
        setupButtonListeners() // Appel pour configurer tous les listeners

        // Initialisation du graphique avec des données de température statiques
        currentDataType = "temperature"
        displayStaticDataOnChart(getStaticDataForType(currentDataType), currentDataType)
    }

    private fun setupButtonListeners() {
        binding.button6.setOnClickListener {
            val intent = Intent(this, Graph24hActivity::class.java)
            intent.putExtra("ZONE_ID", selectedZoneId)
            intent.putExtra("DATA_TYPE_24H", currentDataType)
            startActivity(intent)
        }

        binding.button7.setOnClickListener { // CO2
            currentDataType = "co2"
            displayStaticDataOnChart(getStaticDataForType(currentDataType), currentDataType)
            Toast.makeText(this, "Affichage CO2 (statique)", Toast.LENGTH_SHORT).show()
        }

        binding.button8.setOnClickListener { // °C (Température)
            currentDataType = "temperature"
            displayStaticDataOnChart(getStaticDataForType(currentDataType), currentDataType)
            Toast.makeText(this, "Affichage Température (statique)", Toast.LENGTH_SHORT).show()
        }

        binding.button9.setOnClickListener { // Hygrométrie
            currentDataType = "hygrometrie"
            displayStaticDataOnChart(getStaticDataForType(currentDataType), currentDataType)
            Toast.makeText(this, "Affichage Hygrométrie (statique)", Toast.LENGTH_SHORT).show()
        }

        // AJOUT DU LISTENER POUR button3
        binding.button20.setOnClickListener {
            val intent = Intent(this, moduleventilation::class.java) // Assurez-vous que moduleventilation est le nom correct de votre Activity
            startActivity(intent)
        }
    }

    private fun setupMainChartAppearance() {
        binding.lineChart.description.isEnabled = false
        binding.lineChart.setTouchEnabled(true)
        binding.lineChart.isDragEnabled = true
        binding.lineChart.setScaleEnabled(true)
        binding.lineChart.setPinchZoom(true)
        binding.lineChart.setBackgroundColor(Color.WHITE)

        val xAxis = binding.lineChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)

        val yAxisLeft = binding.lineChart.axisLeft
        yAxisLeft.setDrawGridLines(true)
        binding.lineChart.axisRight.isEnabled = false
        binding.lineChart.legend.isEnabled = true // La légende est activée, assurez-vous que c'est voulu
    }

    private fun getStaticDataForType(dataType: String): List<Entry> {
        val entries = ArrayList<Entry>()
        // Utilisation de lowercase(Locale.ROOT) pour une comparaison insensible à la casse et indépendante de la locale
        when (dataType.lowercase(Locale.ROOT)) {
            "temperature" -> {
                entries.add(Entry(0f, 20f))
                entries.add(Entry(1f, 22f))
                entries.add(Entry(2f, 21f))
                entries.add(Entry(3f, 23f))
                entries.add(Entry(4f, 25f))
                entries.add(Entry(5f, 24f))
            }
            "co2" -> {
                entries.add(Entry(0f, 400f))
                entries.add(Entry(1f, 420f))
                entries.add(Entry(2f, 450f))
                entries.add(Entry(3f, 430f))
                entries.add(Entry(4f, 460f))
                entries.add(Entry(5f, 480f))
            }
            "hygrometrie" -> {
                entries.add(Entry(0f, 50f))
                entries.add(Entry(1f, 55f))
                entries.add(Entry(2f, 52f))
                entries.add(Entry(3f, 58f))
                entries.add(Entry(4f, 56f))
                entries.add(Entry(5f, 60f))
            }
            else -> {
                // Données par défaut si le type n'est pas reconnu
                entries.add(Entry(0f, 10f)); entries.add(Entry(1f, 12f))
                // Pourrait être utile d'ajouter un log ou un Toast ici pour indiquer un type de données inconnu
            }
        }
        return entries
    }

    private fun displayStaticDataOnChart(entries: List<Entry>, dataType: String) {
        if (entries.isEmpty()) {
            binding.lineChart.clear() // Efface le graphique
            binding.lineChart.data = null // S'assurer que les anciennes données sont complètement retirées
            Toast.makeText(this, "Pas de données statiques à afficher pour '$dataType'", Toast.LENGTH_SHORT).show()
            binding.lineChart.invalidate() // Redessine le graphique (maintenant vide)
            return
        }

        val xLabels = arrayOf("T1", "T2", "T3", "T4", "T5", "T6") // Étiquettes pour l'axe X
        binding.lineChart.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index >= 0 && index < xLabels.size) xLabels[index] else value.toString()
            }
        }

        // Capitalisation du premier caractère du type de données pour le label du dataset
        val dataSetLabel = dataType.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() } + " (Statique)"
        val dataSet = LineDataSet(entries, dataSetLabel)
        dataSet.lineWidth = 2.5f
        dataSet.circleRadius = 5f
        dataSet.setDrawCircleHole(true)
        dataSet.circleHoleRadius = 2.5f
        dataSet.valueTextSize = 10f
        dataSet.setDrawValues(true) // Afficher les valeurs sur les points
        dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER // Ligne cubique pour un aspect plus lisse
        dataSet.setDrawFilled(true) // Activer le remplissage sous la ligne

        val fillColorAlpha = 150 // Transparence pour la couleur de remplissage
        // Définition des couleurs basées sur le type de données
        when (dataType.lowercase(Locale.ROOT)) {
            "temperature" -> {
                dataSet.color = Color.MAGENTA
                dataSet.setCircleColor(Color.MAGENTA)
                val colorVal = Color.MAGENTA
                dataSet.fillColor = Color.argb(fillColorAlpha, Color.red(colorVal), Color.green(colorVal), Color.blue(colorVal))
            }
            "co2" -> {
                dataSet.color = Color.GREEN
                dataSet.setCircleColor(Color.GREEN)
                val colorVal = Color.GREEN
                dataSet.fillColor = Color.argb(fillColorAlpha, Color.red(colorVal), Color.green(colorVal), Color.blue(colorVal))
            }
            "hygrometrie" -> {
                dataSet.color = Color.BLUE
                dataSet.setCircleColor(Color.BLUE)
                val colorVal = Color.BLUE
                dataSet.fillColor = Color.argb(fillColorAlpha, Color.red(colorVal), Color.green(colorVal), Color.blue(colorVal))
            }
            else -> {
                dataSet.color = Color.DKGRAY
                dataSet.setCircleColor(Color.DKGRAY)
                val colorVal = Color.DKGRAY
                dataSet.fillColor = Color.argb(fillColorAlpha, Color.red(colorVal), Color.green(colorVal), Color.blue(colorVal))
            }
        }
        dataSet.valueTextColor = Color.DKGRAY // Couleur du texte pour les valeurs sur les points

        val lineData = LineData(dataSet)
        binding.lineChart.data = lineData // Assigner les données au graphique

        // Description du graphique (peut être masquée si non nécessaire via `binding.lineChart.description.isEnabled = false`)
        binding.lineChart.description.text = "Données pour: ${dataType.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }}"
        binding.lineChart.description.textColor = Color.DKGRAY // Optionnel: couleur pour la description
        // binding.lineChart.description.setPosition(x,y) // Pour un positionnement personnalisé si besoin

        binding.lineChart.animateX(800) // Animation sur l'axe X
        binding.lineChart.invalidate() // Redessiner le graphique avec les nouvelles données et configurations
    }
}