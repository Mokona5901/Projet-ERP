package com.example.erp

import android.content.Intent // N'oubliez pas cet import
import android.os.Bundle
import android.view.View // N'oubliez pas cet import
import android.widget.ImageView // N'oubliez pas cet import
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Option 1: lateinit (assurez-vous que R.id.play existe et est bien un ImageView dans votre XML)
    private lateinit var play: ImageView

    // Option 2: Nullable (si vous préférez gérer la nullité explicitement)
    // private var play: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContentView(R.layout.activity_main)

        // Initialisation de la vue
        play = findViewById(R.id.play) // Le type est inféré si 'play' est déclaré avec un type

        // play = findViewById<ImageView>(R.id.play) // Vous pouvez aussi être explicite

        // Configuration du listener de clic
        play.setOnClickListener { // Utilisation d'une lambda expression en Kotlin
            // 'it' fait référence à la vue cliquée (le bouton 'play' ici), si vous en avez besoin
            // Naviguer vers page1Activity2
            val otherActivityIntent = Intent(this, page1Activity2::class.java) // 'this' est le contexte de MainActivity
            startActivity(otherActivityIntent)
            finish() // Ferme MainActivity pour qu'on ne puisse pas y retourner avec le bouton "précédent"
        }
    }
}
