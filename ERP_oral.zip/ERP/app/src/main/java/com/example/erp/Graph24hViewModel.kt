package com.example.erp // Adaptez votre package

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class Graph24hViewModel : ViewModel() {

    private val TAG = "Graph24hViewModel"

    // Référence à notre service API créé via ApiClient
    private val capteurApiService = ApiClient.capteurApiService

    // StateFlow pour exposer la liste des lectures de capteurs à l'Activity
    // MutableStateFlow pour pouvoir la modifier depuis le ViewModel
    private val _donneesCapteurs24h = MutableStateFlow<List<LectureCapteur>>(emptyList())
    val donneesCapteurs24hStateFlow: StateFlow<List<LectureCapteur>> = _donneesCapteurs24h.asStateFlow()

    // StateFlow pour exposer l'état de chargement
    private val _isLoading = MutableStateFlow<Boolean>(false)
    val isLoadingStateFlow: StateFlow<Boolean> = _isLoading.asStateFlow()

    // StateFlow pour exposer les messages d'erreur (optionnel mais recommandé)
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessageStateFlow: StateFlow<String?> = _errorMessage.asStateFlow()

    /**
     * Récupère les données des capteurs pour les dernières 24 heures via l'API.
     * Met à jour les StateFlows avec les résultats ou les erreurs.
     * @param capteurId L'ID optionnel du capteur à filtrer.
     */
    fun recupererDonneesCapteursDernieres24h(capteurId: String?) {
        // Lancer une coroutine dans le scope du ViewModel
        // Cette coroutine sera automatiquement annulée si le ViewModel est détruit
        viewModelScope.launch {
            _isLoading.value = true // Indiquer le début du chargement
            _errorMessage.value = null // Réinitialiser les messages d'erreur précédents
            try {
                Log.d(TAG, "Lancement de la récupération des données pour capteurId: $capteurId")
                // Appel réseau suspendu
                val resultat = capteurApiService.getDonneesCapteursDernieres24h(capteurId)
                _donneesCapteurs24h.value = resultat // Mettre à jour le StateFlow avec les données
                Log.d(TAG, "Données reçues: ${resultat.size} lectures")
            } catch (e: Exception) {
                // Gérer les exceptions (problème réseau, erreur API, etc.)
                Log.e(TAG, "Erreur lors de la récupération des données: ${e.message}", e)
                _errorMessage.value = "Erreur de chargement des données: ${e.localizedMessage}"
                _donneesCapteurs24h.value = emptyList() // Vider les données en cas d'erreur
            } finally {
                _isLoading.value = false // Indiquer la fin du chargement
            }
        }
    }

    /**
     * Appelé lorsque le ViewModel est sur le point d'être détruit.
     * Utile pour nettoyer des ressources si nécessaire, bien que viewModelScope gère déjà l'annulation des coroutines.
     */
    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "ViewModel cleared")
    }
}