package com.example.erp // Assurez-vous que le package est correct

import com.google.gson.annotations.SerializedName

/**
 * Représente une lecture unique d'un capteur, telle que reçue de l'API.
 */
data class LectureCapteur(
    @SerializedName("timestamp") // Correspond au champ "timestamp" dans le JSON
    val timestamp: String,

    @SerializedName("valeur")    // Correspond au champ "valeur" dans le JSON
    val valeur: Float
)