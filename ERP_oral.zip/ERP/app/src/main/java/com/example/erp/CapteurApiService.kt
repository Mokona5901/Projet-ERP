package com.example.erp // Assurez-vous que le package est correct

import retrofit2.Response // Important pour gérer la réponse de la commande
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Interface définissant les endpoints de l'API pour Retrofit.
 * Inclut les capteurs et la gestion des zones.
 */
interface CapteurApiService { // Vous pourriez envisager de la renommer en ApiService si elle gère plus que les capteurs

    // --- Endpoints pour les LECTURES DE CAPTEURS ---

    /**
     * Récupère les données des capteurs pour les dernières 24 heures.
     * Correspond à l'endpoint: /api/capteurs/donnees/dernieres24h
     *
     * @param capteurId L'ID optionnel du capteur (ou module_id) pour filtrer les résultats. Peut être null.
     * @return Une liste d'objets [LectureCapteur].
     */
    @GET("api/capteurs/donnees/dernieres24h")
    suspend fun getDonneesCapteursDernieres24h(
        @Query("capteurId") capteurId: String? // Le '?' indique que le paramètre peut être null
        // Dans votre cas, si vous voulez filtrer par module_id,
        // assurez-vous que votre API Flask gère un paramètre
        // nommé "capteurId" ou adaptez ce nom ici et dans l'API.
        // Ou, si c'est toujours pour toutes les mesures, laissez tel quel.
    ): List<LectureCapteur>

    /**
     * Optionnel : Récupère les données des capteurs pour une plage de dates spécifiée.
     * Correspond à l'endpoint: /api/capteurs/donnees
     *
     * @param capteurId L'ID optionnel du capteur.
     * @param dateDebut La date de début de la plage (format attendu par l'API, ex: "YYYY-MM-DDTHH:MM:SSZ").
     * @param dateFin La date de fin de la plage (format attendu par l'API, ex: "YYYY-MM-DDTHH:MM:SSZ").
     * @return Une liste d'objets [LectureCapteur].
     */
    /* // Décommentez ceci si vous voulez utiliser cet endpoint également
    @GET("api/capteurs/donnees")
    suspend fun getDonneesCapteursPlage(
        @Query("capteurId") capteurId: String?,
        @Query("dateDebut") dateDebut: String,
        @Query("dateFin") dateFin: String
    ): List<LectureCapteur>
    */


    // --- NOUVEAUX ENDPOINTS POUR LA GESTION DES ZONES ---

    /**
     * Récupère la liste de toutes les zones de ventilation.
     * Correspond à l'endpoint: /api/zones
     *
     * @return Une liste d'objets [ZoneInfo].
     */
    @GET("api/zones")
    suspend fun getAllZones(): List<ZoneInfo>

    /**
     * Envoie une commande pour définir la puissance demandée d'une zone spécifique.
     * Correspond à l'endpoint: /api/zones/{id_zone}/commande
     *
     * @param idZone L'ID de la zone à commander (passé dans le chemin de l'URL).
     * @param commandeRequest Le corps de la requête contenant la nouvelle puissance demandée.
     * @return Une [Response] Retrofit encapsulant un objet [CommandeZoneResponse]
     *         pour permettre de vérifier le code de statut HTTP et le corps de la réponse/erreur.
     */
    @POST("api/zones/{id_zone}/commande") // Ou @PUT selon votre préférence pour la sémantique de l'API
    suspend fun setZonePower(
        @Path("id_zone") idZone: Int,
        @Body commandeRequest: CommandeZoneRequest
    ): Response<CommandeZoneResponse> // Utiliser Response<T> est crucial ici
}