package com.example.erp // Assurez-vous que c'est le bon package

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

// Notre "cuisinier intelligent"
class SensorViewModel : ViewModel() {

    // Ceci est comme une "assiette" où le cuisinier mettra les données des capteurs.
    // L'interface (le salon) pourra regarder cette assiette.
    // "_donneesCapteurs" est privé (le cuisinier le gère).
    private val _donneesCapteurs = MutableLiveData<List<LectureCapteur>>()
    // "donneesCapteurs" est public (le salon peut le voir, mais pas le modifier).
    val donneesCapteurs: LiveData<List<LectureCapteur>> = _donneesCapteurs

    // Ceci est pour afficher un message s'il y a un problème (supermarché fermé, etc.).
    private val _messageErreur = MutableLiveData<String?>()
    val messageErreur: LiveData<String?> = _messageErreur

    // C'est la fonction que l'on appellera pour dire au cuisinier : "Va chercher les données !"
    fun chargerDonneesDernieres24h(capteurId: String? = null) {
        // viewModelScope.launch : C'est pour faire le travail en arrière-plan,
        // pour ne pas bloquer l'application pendant que le cuisinier va au supermarché.
        viewModelScope.launch {
            try {
                Log.d("SensorViewModel", "Début du chargement des données pour capteurId: $capteurId")
                // Le cuisinier utilise ApiClient (le téléphone/voiture) pour appeler l'API.
                val lecturesRecues = ApiClient.capteurApiService.getDonneesCapteursDernieres24h(capteurId)

                // Le cuisinier a reçu les données et les met sur l'"assiette".
                _donneesCapteurs.postValue(lecturesRecues)
                _messageErreur.postValue(null) // Pas d'erreur, on efface le message précédent.
                Log.d("SensorViewModel", "Données chargées avec succès: ${lecturesRecues.size} lectures reçues.")

            } catch (e: Exception) {
                // OUPS ! Il y a eu un problème.
                val erreurMsg = "Erreur API: ${e.message}"
                _messageErreur.postValue(erreurMsg)
                Log.e("SensorViewModel", erreurMsg, e) // Affiche l'erreur détaillée dans Logcat pour nous aider.
            }
        }
    }
}