// Dans un nouveau fichier ZoneInfo.kt
package com.example.erp // Ou votre package

import com.google.gson.annotations.SerializedName

data class ZoneInfo(
    @SerializedName("id_zone")
    val idZone: Int,
    @SerializedName("nom")
    val nom: String,
    @SerializedName("module_id") // Si vous en avez besoin côté client
    val moduleId: Int,
    @SerializedName("puissance_actuelle_pourcentage")
    val puissanceActuelle: Int,
    @SerializedName("puissance_demandee_pourcentage")
    val puissanceDemandee: Int
)

// Optionnel: Une classe pour le corps de la requête de commande
data class CommandeZoneRequest(
    @SerializedName("puissance_demandee_pourcentage")
    val puissanceDemandeePourcentage: Int
)

// Optionnel: Une classe pour la réponse simple de la commande
data class CommandeZoneResponse(
    @SerializedName("message")
    val message: String?,
    @SerializedName("erreur")
    val erreur: String?
)