package com.example.erp

import android.graphics.Color
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.text
import androidx.core.text.color
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.erp.databinding.ActivityModuleventilationBinding // Assurez-vous que ce nom est correct
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import java.util.Locale
import kotlin.random.Random

class moduleventilation : AppCompatActivity() { // Nom de classe conservé tel quel

    // Déclaration du ViewBinding
    private lateinit var binding: ActivityModuleventilationBinding
    private var currentDataType: String = DATA_TYPE_DEBIT // Pour suivre le type de données affiché

    companion object {
        const val DATA_TYPE_DEBIT = "debit_air"
        const val DATA_TYPE_PUISSANCE = "puissance_ventilation"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Conservé depuis votre code original

        // Initialisation du ViewBinding
        binding = ActivityModuleventilationBinding.inflate(layoutInflater)
        setContentView(binding.root) // Utiliser la racine du binding pour le contenu

        // Application des WindowInsets (conservé et adapté au binding)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.title = "Module Ventilation" // Titre de l'ActionBar

        // Configuration du graphique et des écouteurs
        setupChartAppearance()
        setupButtonListeners()

        // Afficher le graphique du débit d'air par défaut au démarrage
        currentDataType = DATA_TYPE_DEBIT
        displayDataOnChart(generateSampleData(currentDataType), currentDataType)
    }

    private fun setupChartAppearance() {
        // Assurez-vous que l'ID dans votre XML est bien 'lineChartVentilation'
        // ou adaptez binding.lineChartVentilation en conséquence
        binding.lineChartVentilation.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            setBackgroundColor(Color.LTGRAY)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(true)
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return "T${value.toInt()}"
                    }
                }
            }

            axisLeft.apply {
                setDrawGridLines(true)
            }
            axisRight.isEnabled = false
            legend.isEnabled = true
        }
    }

    private fun setupButtonListeners() {
        // Assurez-vous que les ID dans votre XML sont bien 'buttonDebitAir' et 'buttonPuissance'
        // ou adaptez binding.buttonDebitAir et binding.buttonPuissance
        binding.buttonDebitAir.setOnClickListener {
            currentDataType = DATA_TYPE_DEBIT
            displayDataOnChart(generateSampleData(currentDataType), currentDataType)
        }

        binding.buttonPuissance.setOnClickListener {
            currentDataType = DATA_TYPE_PUISSANCE
            displayDataOnChart(generateSampleData(currentDataType), currentDataType)
        }
    }

    private fun generateSampleData(dataType: String): List<Entry> {
        val entries = ArrayList<Entry>()
        val random = Random(System.currentTimeMillis())
        val numEntries = 20

        for (i in 0 until numEntries) {
            val xValue = i.toFloat()
            val yValue: Float = when (dataType) {
                DATA_TYPE_DEBIT -> 50f + random.nextFloat() * 450f // Simule débit L/s
                DATA_TYPE_PUISSANCE -> 100f + random.nextFloat() * 1900f // Simule puissance W
                else -> 0f
            }
            entries.add(Entry(xValue, yValue))
        }
        return entries
    }

    private fun displayDataOnChart(entries: List<Entry>, dataType: String) {
        if (entries.isEmpty()) {
            binding.lineChartVentilation.clear()
            binding.lineChartVentilation.invalidate()
            return
        }

        val label: String
        val color: Int
        val unit: String

        when (dataType) {
            DATA_TYPE_DEBIT -> {
                label = "Débit d'Air"
                color = Color.CYAN
                unit = " L/s"
            }
            DATA_TYPE_PUISSANCE -> {
                label = "Puissance Ventilation"
                color = Color.MAGENTA
                unit = " W"
            }
            else -> {
                label = "Données Inconnues"
                color = Color.GRAY
                unit = ""
            }
        }

        val dataSet = LineDataSet(entries, label).apply {
            this.color = color
            this.valueTextColor = Color.BLACK
            this.lineWidth = 2.5f
            this.circleRadius = 4f
            this.setCircleColor(color)
            this.setDrawValues(true)
            this.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "${String.format(Locale.getDefault(), "%.1f", value)}$unit"
                }
            }
            setDrawFilled(true)
            fillColor = color
            fillAlpha = 50
        }

        val lineData = LineData(dataSet)
        binding.lineChartVentilation.data = lineData
        binding.lineChartVentilation.description.text = "$label sur le temps"
        binding.lineChartVentilation.animateX(800)
        binding.lineChartVentilation.invalidate()
    }
}