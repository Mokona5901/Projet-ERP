package com.example.projeterp

import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class ChartActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart)
        barChart = findViewById(R.id.barChart)
        loadSalesData()
    }

    private fun loadSalesData() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://yourdomain.com/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api = retrofit.create(ApiService::class.java)
        api.getSales().enqueue(object : Callback<List<Sale>> {
            override fun onResponse(call: Call<List<Sale>>, response: Response<List<Sale>>) {
                if (response.isSuccessful) {
                    response.body()?.let { showBarChart(it) }
                }
            }

            override fun onFailure(call: Call<List<Sale>>, t: Throwable) {
                Toast.makeText(this@ChartActivity, "Erreur: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showBarChart(sales: List<Sale>) {
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()

        sales.forEachIndexed { index, sale ->
            entries.add(BarEntry(index.toFloat(), sale.amount.toFloat()))
            labels.add(sale.day)
        }

        val dataSet = BarDataSet(entries, "Ventes par jour")
        dataSet.color = Color.BLUE
        val data = BarData(dataSet)
        data.barWidth = 0.9f

        barChart.apply {
            this.data = data
            xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.granularity = 1f
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false
            description.isEnabled = false
            setFitBars(true)
            invalidate()
        }
    }
}