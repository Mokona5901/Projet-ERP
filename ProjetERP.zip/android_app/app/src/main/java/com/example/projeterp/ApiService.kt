package com.example.projeterp

import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("get_sales.php")
    fun getSales(): Call<List<Sale>>
}