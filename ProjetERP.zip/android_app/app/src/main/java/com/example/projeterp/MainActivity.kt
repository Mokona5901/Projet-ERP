package com.example.projeterp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLoadChart: Button = findViewById(R.id.btnLoadChart)
        btnLoadChart.setOnClickListener {
            startActivity(Intent(this, ChartActivity::class.java))
        }
    }
}