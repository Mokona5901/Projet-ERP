package com.example.projeterp

data class Sale(val day: String, val amount: Int)