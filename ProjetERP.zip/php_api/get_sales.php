<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "user", "password", "database_name");
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed"]));
}
$sql = "SELECT day, amount FROM sales";
$result = $conn->query($sql);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
$conn->close();
?>